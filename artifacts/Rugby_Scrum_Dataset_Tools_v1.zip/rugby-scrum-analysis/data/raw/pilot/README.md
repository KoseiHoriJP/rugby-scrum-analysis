# Rugby Scrum Pilot Dataset

実写のラグビースクラムを YOLO Pose で分析するための初期検証用データセットです。3試合のMP4 5本と、スクラム区間から毎秒約5フレームで抽出した279フレーム分の骨格推定結果を収録しています。映像は横・斜め視点です。

## ファイル

| パス | 内容 |
|---|---|
| `videos/` | Wikimedia Commons の素材を H.264 MP4 に変換した映像5本。スクラムの前後も含みます。 |
| `clips.csv` | 試合、カメラ視点、動画の仕様、分析区間、切り出し領域、出典。 |
| `skeleton_previews/` | スクラム周辺を切り出し、推定骨格を重ねた確認用MP4。各5 fps、音声なし。 |
| `sampled_frames.csv` | サンプル番号、MP4のフレーム番号、時刻（秒）、検出数。検出数が0のフレームも記録。 |
| `detections.csv` | フレーム内で検出された人物候補ごとの矩形と検出信頼度。 |
| `yolo_keypoints.csv` | 人物候補ごとのCOCO形式17点。各行に関節名、2D座標、関節の信頼度。 |
| `aerial_candidates.csv` | 真上・高所リプレイの追加収集候補。確認できた範囲を記載したリンク集。 |

## データの見方

1. `skeleton_previews/uruguay_argentina_02_pose.mp4` を開き、組む前と組んだ後で肩・腰の骨格がどれくらい見えるか確認します。
2. `sampled_frames.csv` の `clip_id` と `source_frame_index` で、元のMP4と推定結果を対応付けます。フレーム番号は0始まりです。
3. `detections.csv` と `yolo_keypoints.csv` は `clip_id`、`source_frame_index`、`detection_index` で結合できます。 `detection_index` とプレビューの色は各フレーム内の識別用です。

座標の原点は `videos/` の各MP4の左上で、単位はピクセルです。プレビューは切り出し後の映像なので、プレビュー上にCSVの点を描く場合は `clips.csv` のROI左上の座標を差し引きます。ROIの右・下端と、サンプリング区間の終了時刻は範囲に含めません。

## 推定条件と確認範囲

- Ultralytics 8.3.221、`yolo11s-pose.pt`、COCO 17点。モデル情報は [Ultralytics Pose](https://docs.ultralytics.com/tasks/pose/) を参照。
- `clips.csv` のROIを切り出し、入力サイズ640、検出信頼度0.25、NMS IoU 0.70で推論。プレビューでは信頼度0.50以上の胴体と四肢の点を描画しました。
- 279フレームの合計で1,378件の人物候補と23,426件の関節行を記録しています。選手、レフェリー、重複検出が含まれ得ます。
- 骨格座標は汎用モデルの自動推定値です。組んでいる選手は互いに隠れるため、特に前列の肩・腰の抜けや別人の関節への誤検出を目視で確認してください。姿勢、力、判定の評価には、目的に応じた正解ラベルを別途作成します。
- 同じ試合のクリップをまとめる `match_group` を付けています。後で評価用の分割を作る場合は、この列を使って試合単位で分けられます。

## 映像の出典

各映像の出典URLと撮影者は `clips.csv` に記載しました。ウルグアイ対アルゼンチンXVの映像は NaBUru38、イタリア対チリの映像は Superchilum の撮影で、いずれも [CC BY-SA 4.0](https://creativecommons.org/licenses/by-sa/4.0/) です。アマトーリ・ミラノ対カルヴィザーノの映像は Snowdog がパブリックドメインとして提供しています。収録版にはMP4への変換、プレビュー版には切り出しと骨格オーバーレイの加工を行いました。
